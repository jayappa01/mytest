import Card from '../UI/Card';
import MealItem from './ProductItem/ProductItem';
import classes from './AvailableProduct.module.css';

const DUMMY_PRODUCTS = [
  {
    id: 'p1',
    name: 'product1',
    description: 'a Product catalog test',
    price: 22.99,
  },
  {
    id: 'p2',
    name: 'product2',
    description: 'a Product catalog test!',
    price: 16.5,
  },
  {
    id: 'p3',
    name: 'product3',
    description: 'a Product catalog test',
    price: 12.99,
  },
  {
    id: 'p4',
    name: 'product4',
    description: 'a Product catalog test',
    price: 18.99,
  },
];

const AvailableMeals = () => {
  const mealsList = DUMMY_PRODUCTS.map((product) => (
    <MealItem
      key={product.id}
      id={product.id}
      name={product.name}
      description={product.description}
      price={product.price}
    />
  ));

  return (
    <section className={classes.meals}>
      <Card>
        <ul>{mealsList}</ul>
      </Card>
    </section>
  );
};

export default AvailableMeals;
