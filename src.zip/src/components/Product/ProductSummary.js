import classes from './ProductSummary.module.css';

const ProductSummary = () => {
  return (
    <section className={classes.summary}>
      <h2>React / Vue / Angular Practical Test
Project Name: Product Catalog with cart</h2>
      <p>
      The goal of this task is to create a Product catalog interface with cart feature. Create an application by the following steps:
Create your own JSON data for multiple product details. 
      </p>
      <p>
      Create another JSON file to maintain inventory for all available products.
Create component to list the products on the page with details. There should be two different layouts to list the products on the page. i.e. Table
view and Grid view. Add a switch to change between these two.
      </p>
    </section>
  );
};

export default ProductSummary;
