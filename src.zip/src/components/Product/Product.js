import { Fragment } from 'react';

import ProductSummary from './ProductSummary';
import AvailableMeals from './AvailableProduct';

const Product = () => {
  return (
    <Fragment>
      <ProductSummary />
      <AvailableMeals />
    </Fragment>
  );
};

export default Product;
