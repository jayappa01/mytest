<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AddSingleGameResultController extends Controller
{
    //
    public function __construct() {
        
    }
    
   public function handleAddSingleGameResult() {
    return \View::make('Broker.Add_Game_Double_Result');
    }
    
 	public function handleAddSingleGameResult() {
        return \View::make('Broker.Add_Game_Double_Result');
    }
    
}
